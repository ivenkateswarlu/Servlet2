package com.training.entity;

public class Doctor {
	String name="Venky";
	double counstlantyFee=1500.00;
	int experience=10;
	Clinic clinic=new Clinic();
	
	
	
	
	public Clinic getClinic() {
		return clinic;
	}
	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCounstlantyFee() {
		return counstlantyFee;
	}
	public void setCounstlantyFee(double counstlantyFee) {
		this.counstlantyFee = counstlantyFee;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	

}
