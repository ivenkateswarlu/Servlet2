package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet(
		urlPatterns = { "/StudentServlet" }, 
		initParams = { 
				@WebInitParam(name = "i_RollNumber", value = "105"), 
				@WebInitParam(name = "i_Name", value = "venky"), 
				@WebInitParam(name = "i_Age", value = "21")
		})
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	private int rollNumber;
	private int age;
	private String name;
	@Override
	public void init() throws ServletException {
		ServletConfig config=getServletConfig();
		String strRoll=config.getInitParameter("i_RollNumber");
		String strName=config.getInitParameter("i_Name");
		String strAge=config.getInitParameter("i_Age");
		this.rollNumber=Integer.parseInt(strRoll);
		this.name=strName;
		this.age=Integer.parseInt(strAge);
		
	}

	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println(rollNumber+"<br>"+name+"<br>"+age+"<br>");
	}

}
